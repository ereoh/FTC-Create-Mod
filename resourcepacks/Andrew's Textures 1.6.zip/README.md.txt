Credits:
- Mizuno's 16 craft: misc. blocks, villagers, etc.
- vanillatweaks.net: 3D rails, animated campfire items, etc.
- Extended illumina: 3D handheld lantern and torch models
- Detail brush: entirely included in this pack